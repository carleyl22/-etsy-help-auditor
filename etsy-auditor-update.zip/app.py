"""
Etsy Help Center Auditor - Streamlit Web Application
"""

import os
import streamlit as st

from auditor import (
    ZendeskClient,
    ContentAnalyzer,
    UIVerifier,
    generate_report,
)


def get_secret(key: str, default: str = "") -> str:
    try:
        if hasattr(st, 'secrets') and key in st.secrets:
            return str(st.secrets[key])
    except Exception:
        pass
    return os.environ.get(key, default)


st.set_page_config(
    page_title="Etsy Help Center Auditor",
    page_icon="📝",
    layout="wide",
)

st.markdown("""
<style>
    .score-excellent { color: #28a745; font-size: 2.5em; font-weight: bold; }
    .score-good { color: #5cb85c; font-size: 2.5em; font-weight: bold; }
    .score-needswork { color: #f0ad4e; font-size: 2.5em; font-weight: bold; }
    .score-critical { color: #d9534f; font-size: 2.5em; font-weight: bold; }
    .issue-critical { background-color: #f8d7da; padding: 15px; border-radius: 8px; margin: 10px 0; border-left: 4px solid #d9534f; }
    .issue-warning { background-color: #fff3cd; padding: 15px; border-radius: 8px; margin: 10px 0; border-left: 4px solid #f0ad4e; }
    .issue-suggestion { background-color: #d1ecf1; padding: 15px; border-radius: 8px; margin: 10px 0; border-left: 4px solid #17a2b8; }
    .strength-box { background-color: #d4edda; padding: 12px; border-radius: 8px; margin: 8px 0; border-left: 4px solid #28a745; }
    .quickwin-box { background-color: #e7f3ff; padding: 12px; border-radius: 8px; margin: 8px 0; border-left: 4px solid #007bff; }
    .original-text { background-color: #ffebee; padding: 10px; border-radius: 4px; font-family: monospace; margin: 5px 0; }
    .suggested-text { background-color: #e8f5e9; padding: 10px; border-radius: 4px; font-family: monospace; margin: 5px 0; }
    .category-score { padding: 8px 12px; border-radius: 4px; margin: 4px; display: inline-block; }
</style>
""", unsafe_allow_html=True)


def init_session_state():
    if "zendesk_client" not in st.session_state:
        st.session_state.zendesk_client = None
    if "analyzer" not in st.session_state:
        st.session_state.analyzer = None
    if "ui_verifier" not in st.session_state:
        st.session_state.ui_verifier = None
    if "anthropic_key" not in st.session_state:
        st.session_state.anthropic_key = None
    if "audit_history" not in st.session_state:
        st.session_state.audit_history = []
    if "connected" not in st.session_state:
        st.session_state.connected = False
    if "last_report" not in st.session_state:
        st.session_state.last_report = None
    if "last_analysis" not in st.session_state:
        st.session_state.last_analysis = None
    if "last_ui_report" not in st.session_state:
        st.session_state.last_ui_report = None


def connect_services():
    with st.sidebar:
        st.header("🔐 Configuration")

        zendesk_email = get_secret("ZENDESK_EMAIL")
        zendesk_token = get_secret("ZENDESK_API_TOKEN")
        anthropic_key = get_secret("ANTHROPIC_API_KEY")

        zendesk_email = st.text_input("Zendesk Email", value=zendesk_email)
        zendesk_token = st.text_input("Zendesk API Token", value=zendesk_token, type="password")
        anthropic_key = st.text_input("Anthropic API Key", value=anthropic_key, type="password")

        if st.button("Connect", type="primary"):
            with st.spinner("Connecting..."):
                try:
                    client = ZendeskClient(
                        subdomain="etsy",
                        email=zendesk_email,
                        api_token=zendesk_token
                    )
                    if not client.test_connection():
                        st.error("Failed to connect to Zendesk.")
                        return
                    analyzer = ContentAnalyzer(api_key=anthropic_key)
                    ui_verifier = UIVerifier(anthropic_api_key=anthropic_key)
                    st.session_state.zendesk_client = client
                    st.session_state.analyzer = analyzer
                    st.session_state.ui_verifier = ui_verifier
                    st.session_state.anthropic_key = anthropic_key
                    st.session_state.connected = True
                    st.success("Connected!")
                except Exception as e:
                    st.error(f"Error: {str(e)}")

        if st.session_state.connected:
            st.success("✓ Connected")
        else:
            st.warning("Not connected")


def get_score_color(score):
    if score >= 90:
        return "#28a745"
    elif score >= 75:
        return "#5cb85c"
    elif score >= 60:
        return "#f0ad4e"
    else:
        return "#d9534f"


def render_score_card(report, analysis):
    st.markdown("### 📊 Overall Score")

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        score_class = (
            "score-excellent" if report.overall_score >= 90
            else "score-good" if report.overall_score >= 75
            else "score-needswork" if report.overall_score >= 60
            else "score-critical"
        )
        st.markdown(f"<div class='{score_class}'>{report.overall_score}/100</div>", unsafe_allow_html=True)
        st.caption(report.quality_rating)
    with col2:
        st.metric("🔴 Critical", len(report.critical_issues))
    with col3:
        st.metric("🟡 Warnings", len(report.warnings))
    with col4:
        st.metric("🔵 Suggestions", len(report.suggestions))

    # Category scores breakdown
    if hasattr(analysis, 'category_scores') and analysis.category_scores:
        st.markdown("### 📈 Category Breakdown")

        score_labels = {
            "title_seo": "Title & SEO",
            "audience_alignment": "Audience",
            "step_completeness": "Steps",
            "ui_accuracy": "UI Accuracy",
            "conciseness": "Conciseness",
            "scannability": "Scannability",
            "information_hierarchy": "Hierarchy",
            "scope": "Scope",
            "technical_hygiene": "Technical",
            "accessibility": "Accessibility"
        }

        cols = st.columns(5)
        for i, (key, label) in enumerate(score_labels.items()):
            score = analysis.category_scores.get(key, 0)
            color = get_score_color(score)
            with cols[i % 5]:
                st.markdown(f"""
                <div style="text-align: center; padding: 10px; background-color: {color}20; border-radius: 8px; margin: 5px 0;">
                    <div style="font-size: 1.5em; font-weight: bold; color: {color};">{score}</div>
                    <div style="font-size: 0.8em; color: #666;">{label}</div>
                </div>
                """, unsafe_allow_html=True)


def render_detailed_issue(issue):
    css_class = f"issue-{issue.severity}"
    icon = {"critical": "🔴", "warning": "🟡", "suggestion": "🔵"}.get(issue.severity, "⚪")

    html = f"<div class='{css_class}'>"
    html += f"<strong>{icon} {issue.description}</strong>"

    if issue.location:
        html += f"<br><em>📍 Location:</em> {issue.location}"

    html += "</div>"
    st.markdown(html, unsafe_allow_html=True)

    # Show original vs suggested in columns
    if issue.original_text or issue.suggested_text:
        col1, col2 = st.columns(2)
        with col1:
            if issue.original_text:
                st.markdown("**❌ Original:**")
                st.markdown(f"<div class='original-text'>{issue.original_text}</div>", unsafe_allow_html=True)
        with col2:
            if issue.suggested_text:
                st.markdown("**✅ Suggested:**")
                st.markdown(f"<div class='suggested-text'>{issue.suggested_text}</div>", unsafe_allow_html=True)

    if issue.recommendation:
        st.markdown(f"💡 *{issue.recommendation}*")

    st.markdown("---")


def render_issues(issues, category_name):
    if not issues:
        st.success(f"No {category_name.lower()} issues found! 🎉")
        return

    st.markdown(f"**Found {len(issues)} issue(s):**")
    for issue in issues:
        render_detailed_issue(issue)


def audit_article(url_or_id: str):
    if not st.session_state.connected:
        st.error("Please connect first.")
        return None, None, None

    client = st.session_state.zendesk_client
    analyzer = st.session_state.analyzer
    ui_verifier = st.session_state.ui_verifier
    anthropic_key = st.session_state.anthropic_key

    with st.spinner("Fetching article from Zendesk..."):
        try:
            article = client.get_article(url_or_id)
        except Exception as e:
            st.error(f"Fetch failed: {str(e)}")
            return None, None, None

    with st.spinner("🔍 Running deep content analysis with Claude (15-30 seconds)..."):
        try:
            analysis = analyzer.analyze(article)
        except Exception as e:
            st.error(f"Analysis failed: {type(e).__name__}: {str(e)}")
            return None, None, None

    with st.spinner("🖥️ Verifying UI against live Etsy site & app (10-20 seconds)..."):
        try:
            if ui_verifier:
                ui_report = ui_verifier.verify_article(article.body, anthropic_key)
            else:
                ui_report = None
        except Exception as e:
            st.warning(f"UI verification error: {str(e)}")
            ui_report = None

    report = generate_report(article, analysis, ui_report)
    st.session_state.audit_history.append({
        "title": report.article_title,
        "score": report.overall_score,
        "issues": report.total_issues,
    })
    return report, analysis, ui_report


def main():
    init_session_state()

    st.title("📝 Etsy Help Center Auditor")
    st.markdown("*Deep-dive content audits for help.etsy.com articles*")

    connect_services()

    tab1, tab2, tab3 = st.tabs(["🔍 Single Audit", "📚 Batch Audit", "📊 Search"])

    with tab1:
        st.header("Audit a Single Article")
        col1, col2 = st.columns([3, 1])
        with col1:
            article_input = st.text_input(
                "Article URL or ID",
                placeholder="https://help.etsy.com/hc/en-us/articles/123456789?segment=selling"
            )
        with col2:
            st.write("")
            st.write("")
            audit_button = st.button("🔍 Run Deep Audit", type="primary", disabled=not st.session_state.connected)

        if audit_button and article_input:
            report, analysis, ui_report = audit_article(article_input)
            st.session_state.last_report = report
            st.session_state.last_analysis = analysis
            st.session_state.last_ui_report = ui_report

        # Display results if we have them
        report = st.session_state.last_report
        analysis = st.session_state.last_analysis
        ui_report = st.session_state.last_ui_report

        if report and analysis:
            st.divider()

            # Article header
            st.subheader(report.article_title)
            st.caption(f"[🔗 View Live Article]({report.article_url})")

            # Score card with category breakdown
            render_score_card(report, analysis)

            st.divider()

            # Executive Summary
            if report.summary:
                st.markdown("### 📋 Executive Summary")
                st.info(report.summary)

            # Two-column layout for strengths and quick wins
            col1, col2 = st.columns(2)

            with col1:
                if hasattr(analysis, 'strengths') and analysis.strengths:
                    st.markdown("### ✅ What's Working Well")
                    for strength in analysis.strengths:
                        st.markdown(f"<div class='strength-box'>✓ {strength}</div>", unsafe_allow_html=True)

            with col2:
                if hasattr(analysis, 'quick_wins') and analysis.quick_wins:
                    st.markdown("### ⚡ Quick Wins")
                    for win in analysis.quick_wins:
                        st.markdown(f"<div class='quickwin-box'>→ {win}</div>", unsafe_allow_html=True)

            st.divider()

            # Detailed Analysis Sections
            st.markdown("### 🔬 Detailed Analysis")

            analysis_tabs = st.tabs([
                "📋 Overview",
                "🖥️ LIVE SITE CHECK",
                "✅ Actionable",
                "📝 Brief",
                "🎯 Targeted",
                "⚙️ Technical",
                "👥 Audience",
                "📄 Full Report"
            ])

            with analysis_tabs[0]:
                # Overview tab with title, structure, completeness analysis
                col1, col2 = st.columns(2)

                with col1:
                    st.markdown("**Audience Detection**")
                    st.write(f"• Declared: **{report.declared_audience}**")
                    st.write(f"• Detected: **{report.detected_audience}**")
                    if report.audience_mismatch:
                        st.error("⚠️ Audience mismatch detected!")

                    st.markdown("**Platform Coverage**")
                    st.write(f"• Web instructions: {'✅' if report.has_web_instructions else '❌ Missing'}")
                    st.write(f"• App instructions: {'✅' if report.has_app_instructions else '❌ Missing'}")

                with col2:
                    if hasattr(analysis, 'title_analysis') and analysis.title_analysis:
                        st.markdown("**Title Analysis**")
                        st.write(analysis.title_analysis)

                if hasattr(analysis, 'structure_analysis') and analysis.structure_analysis:
                    st.markdown("**Structure Analysis**")
                    st.write(analysis.structure_analysis)

                if hasattr(analysis, 'completeness_analysis') and analysis.completeness_analysis:
                    st.markdown("**Completeness Analysis**")
                    st.write(analysis.completeness_analysis)

                if report.member_services_flag:
                    st.error(f"🚨 **Member Services Flag:** {report.flag_reason}")

            with analysis_tabs[1]:
                # LIVE SITE VERIFICATION TAB
                st.markdown("### 🖥️ Live Site & App Verification")
                st.markdown("*Checking if article instructions match the actual Etsy website and app*")

                if ui_report:
                    # Summary banner
                    if ui_report.critical_mismatches:
                        st.error(f"🚨 **{len(ui_report.critical_mismatches)} CRITICAL UI MISMATCH(ES) FOUND** - Instructions may not match live site!")
                    elif ui_report.needs_manual_review:
                        st.warning(f"⚠️ Some UI elements need manual verification")
                    else:
                        st.success("✅ UI elements appear to match current Etsy interface")

                    # Confidence score
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        confidence_pct = int(ui_report.confidence_score * 100)
                        color = get_score_color(confidence_pct)
                        st.markdown(f"""
                        <div style="text-align: center; padding: 15px; background-color: {color}20; border-radius: 8px;">
                            <div style="font-size: 2em; font-weight: bold; color: {color};">{confidence_pct}%</div>
                            <div>UI Confidence</div>
                        </div>
                        """, unsafe_allow_html=True)
                    with col2:
                        st.metric("UI Elements Found", len(ui_report.elements_found))
                    with col3:
                        verified = len([r for r in ui_report.results if r.status == "verified"])
                        st.metric("Verified", f"{verified}/{len(ui_report.results)}")

                    st.markdown(f"**Summary:** {ui_report.verification_summary}")

                    # Critical mismatches
                    if ui_report.critical_mismatches:
                        st.markdown("### 🚨 Critical Mismatches")
                        st.markdown("*These UI references don't match the current Etsy site:*")
                        for mismatch in ui_report.critical_mismatches:
                            st.markdown(f"""
                            <div class='issue-critical'>
                                <strong>❌ {mismatch}</strong>
                            </div>
                            """, unsafe_allow_html=True)

                    # Detailed verification results
                    if ui_report.results:
                        st.markdown("### 📋 Detailed Verification")

                        for result in ui_report.results:
                            if result.status == "verified":
                                icon = "✅"
                                color = "#d4edda"
                            elif result.status == "outdated":
                                icon = "❌"
                                color = "#f8d7da"
                            else:
                                icon = "❓"
                                color = "#fff3cd"

                            with st.expander(f"{icon} {result.element.text} ({result.element.element_type})"):
                                st.write(f"**Status:** {result.status.upper()}")
                                st.write(f"**Confidence:** {result.confidence:.0%}")
                                st.write(f"**Platform:** {result.element.platform}")
                                if result.notes:
                                    st.write(f"**Notes:** {result.notes}")
                                if result.current_ui:
                                    st.error(f"**Current UI:** {result.current_ui}")
                                st.caption(f"Context: ...{result.element.context[:100]}...")

                    # Manual review items
                    if ui_report.manual_review_items:
                        st.markdown("### 👀 Needs Manual Review")
                        st.info("These elements couldn't be automatically verified - please check manually on etsy.com:")
                        for item in ui_report.manual_review_items:
                            st.write(f"• {item}")
                else:
                    st.info("UI verification not available. Connect with Anthropic API key for live site checking.")

            with analysis_tabs[2]:
                actionable_issues = [i for i in report.actionable_issues]
                render_issues(actionable_issues, "Actionable")

            with analysis_tabs[3]:
                render_issues(report.brief_issues, "Brief/Conciseness")

            with analysis_tabs[4]:
                render_issues(report.targeted_issues, "Targeted/Hierarchy")

            with analysis_tabs[5]:
                render_issues(report.technical_issues, "Technical")
                if report.hardcoded_links:
                    st.warning("**🔗 Hardcoded Links Found:**")
                    for link in report.hardcoded_links:
                        st.code(link)

            with analysis_tabs[6]:
                render_issues(report.audience_issues, "Audience")

            with analysis_tabs[7]:
                # Full downloadable report
                st.markdown("### Download Full Report")
                col1, col2 = st.columns(2)
                with col1:
                    st.download_button(
                        "📄 Download Markdown Report",
                        report.to_markdown(),
                        file_name=f"audit_{report.article_id}.md",
                        mime="text/markdown"
                    )
                with col2:
                    st.download_button(
                        "📊 Download JSON Report",
                        report.to_json(),
                        file_name=f"audit_{report.article_id}.json",
                        mime="application/json"
                    )

                st.markdown("### Raw Markdown Preview")
                st.text_area("Report Content", report.to_markdown(), height=400)

    with tab2:
        st.header("Batch Audit")
        st.info("Enter multiple article URLs or IDs, one per line. Each audit takes 15-30 seconds.")
        batch_input = st.text_area("Article URLs/IDs (one per line)", height=150)

        if st.button("🔍 Audit All Articles", type="primary", disabled=not st.session_state.connected):
            if batch_input:
                articles = [a.strip() for a in batch_input.split("\n") if a.strip()]
                results = []
                progress = st.progress(0)
                status = st.empty()

                for i, article in enumerate(articles):
                    status.text(f"Auditing {i+1}/{len(articles)}: {article[:50]}...")
                    report, analysis, ui_report = audit_article(article)
                    if report:
                        results.append(report)
                    progress.progress((i + 1) / len(articles))

                status.text("Complete!")

                if results:
                    st.divider()
                    st.subheader("📊 Batch Results Summary")

                    import pandas as pd
                    df = pd.DataFrame([{
                        "Title": r.article_title[:50],
                        "Score": r.overall_score,
                        "Critical": len(r.critical_issues),
                        "Warnings": len(r.warnings),
                        "Web": "✅" if r.has_web_instructions else "❌",
                        "App": "✅" if r.has_app_instructions else "❌",
                        "MS Flag": "⚠️" if r.member_services_flag else "✓"
                    } for r in results])
                    st.dataframe(df, use_container_width=True)

                    # Summary stats
                    avg_score = sum(r.overall_score for r in results) / len(results)
                    st.metric("Average Score", f"{avg_score:.0f}/100")

                    all_reports = "\n\n---\n\n".join([r.to_markdown() for r in results])
                    st.download_button(
                        "📄 Download All Reports",
                        all_reports,
                        file_name="batch_audit_report.md",
                        mime="text/markdown"
                    )

    with tab3:
        st.header("Search Articles")
        search_query = st.text_input("Search help.etsy.com", placeholder="refund policy")

        if st.button("🔍 Search", disabled=not st.session_state.connected):
            if search_query:
                with st.spinner("Searching..."):
                    try:
                        results = st.session_state.zendesk_client.search_articles(search_query)
                        if results:
                            st.write(f"Found {len(results)} articles:")
                            for article in results[:10]:
                                with st.expander(f"📄 {article.title}"):
                                    st.write(f"**ID:** {article.id}")
                                    st.write(f"**URL:** {article.html_url}")
                        else:
                            st.info("No results found.")
                    except Exception as e:
                        st.error(f"Search failed: {str(e)}")


if __name__ == "__main__":
    main()
