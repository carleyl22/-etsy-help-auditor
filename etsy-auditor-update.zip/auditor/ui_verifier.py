"""Live UI verification against Etsy website and app."""

import re
from dataclasses import dataclass, field
from typing import Optional
import requests
from bs4 import BeautifulSoup
from anthropic import Anthropic


@dataclass
class UIElement:
    """A UI element mentioned in the article."""
    text: str
    element_type: str  # 'button', 'navigation', 'menu', 'link', 'tab', 'page'
    context: str
    platform: str  # 'web', 'app', 'both', 'unknown'


@dataclass
class VerificationResult:
    """Result of verifying a UI element."""
    element: UIElement
    status: str  # 'verified', 'outdated', 'unverified', 'mismatch'
    confidence: float
    notes: Optional[str] = None
    current_ui: Optional[str] = None  # What it actually is now
    source: Optional[str] = None


@dataclass
class LiveVerificationReport:
    """Complete live verification report."""
    elements_found: list[UIElement] = field(default_factory=list)
    results: list[VerificationResult] = field(default_factory=list)
    etsy_pages_checked: list[str] = field(default_factory=list)
    verification_summary: str = ""
    critical_mismatches: list[str] = field(default_factory=list)
    confidence_score: float = 0.0
    needs_manual_review: bool = False
    manual_review_items: list[str] = field(default_factory=list)


# Known current Etsy UI structure (updated regularly)
CURRENT_ETSY_UI = {
    # Seller - Shop Manager main navigation
    "shop_manager_nav": [
        "Listings", "Messages", "Orders & Shipping", "Star Seller",
        "Ads & Offsite Ads", "Finances", "Settings", "Integrations",
        "Community & Help"
    ],

    # Seller - Listings page
    "listings_actions": [
        "Add a listing", "Edit", "Copy", "Deactivate", "Delete", "Renew",
        "Edit shipping profiles", "Edit return policies"
    ],

    # Seller - Order management
    "order_actions": [
        "Mark as shipped", "Print shipping label", "Issue a refund",
        "Cancel order", "Report a problem", "Add tracking"
    ],

    # Seller - Settings sections
    "settings_sections": [
        "Shop details", "Shipping settings", "Return policies",
        "Payment settings", "Billing", "Legal and privacy"
    ],

    # Buyer - Main navigation
    "buyer_nav": [
        "Favorites", "Cart", "Your account", "Purchases and reviews",
        "Messages", "Account settings"
    ],

    # Buyer - Account sections
    "account_sections": [
        "Purchases and reviews", "Account settings", "Addresses",
        "Payment methods", "Emails and notifications", "Privacy settings"
    ],

    # Common buttons
    "common_buttons": [
        "Save", "Cancel", "Submit", "Continue", "Done", "Apply",
        "Edit", "Delete", "Remove", "Add", "Update"
    ],

    # App-specific navigation
    "app_nav": [
        "Home", "Search", "Favorites", "Cart", "You"
    ],

    # App - You tab sections (seller)
    "app_seller_sections": [
        "Shop Manager", "Listings", "Orders", "Messages", "Stats"
    ]
}

# Pages we can verify against
VERIFIABLE_PAGES = {
    "homepage": "https://www.etsy.com",
    "help_center": "https://help.etsy.com",
    "seller_handbook": "https://www.etsy.com/seller-handbook",
    "legal_policies": "https://www.etsy.com/legal",
    "fees": "https://www.etsy.com/legal/fees",
}


class UIVerifier:
    """Verifies article instructions against live Etsy UI."""

    def __init__(self, anthropic_api_key: str = None):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
        })
        self.anthropic_key = anthropic_api_key
        self.client = None
        if anthropic_api_key:
            self.client = Anthropic(api_key=anthropic_api_key)

    def _fetch_page(self, url: str) -> Optional[str]:
        """Fetch a page from Etsy."""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception:
            return None

    def _extract_ui_elements(self, html_content: str) -> list[UIElement]:
        """Extract all UI references from article content."""
        soup = BeautifulSoup(html_content, "lxml")
        text = soup.get_text(separator=" ", strip=True)
        elements = []

        # Navigation paths: "Go to Shop Manager > Settings > Shipping"
        nav_patterns = [
            r'(?:Go to|Navigate to|Select|Click|Tap|Open|From|In|Under)\s+([A-Z][^.!?\n]{3,60}(?:\s*[>→]\s*[A-Z][^.!?\n>→]{2,40})*)',
            r'(?:the\s+)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:tab|page|section|menu|button)',
        ]

        for pattern in nav_patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                path = match.group(1).strip()
                if len(path) > 3:
                    start = max(0, match.start() - 100)
                    end = min(len(text), match.end() + 100)
                    context = text[start:end]

                    platform = "unknown"
                    if "app" in context.lower() or "mobile" in context.lower():
                        platform = "app"
                    elif "website" in context.lower() or "etsy.com" in context.lower():
                        platform = "web"

                    elements.append(UIElement(
                        text=path,
                        element_type="navigation",
                        context=context,
                        platform=platform
                    ))

        # Button/link names in quotes or formatting
        button_patterns = [
            r'["""]([^"""]{2,40})["""]',
            r'\*\*([^*]{2,40})\*\*',
            r'(?:click|tap|select|choose)\s+(?:on\s+)?(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:button|link|option)',
        ]

        for pattern in button_patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                button_text = match.group(1).strip()
                if len(button_text) >= 2 and len(button_text) <= 40:
                    if not any(c in button_text for c in ['http', 'www', '.com']):
                        elements.append(UIElement(
                            text=button_text,
                            element_type="button",
                            context=text[max(0, match.start()-50):min(len(text), match.end()+50)],
                            platform="unknown"
                        ))

        return elements

    def _verify_against_known_ui(self, element: UIElement) -> Optional[VerificationResult]:
        """Check element against known current UI structure."""
        element_lower = element.text.lower()

        # Check against all known UI categories
        for category, items in CURRENT_ETSY_UI.items():
            items_lower = [item.lower() for item in items]

            # Exact match
            if element_lower in items_lower:
                return VerificationResult(
                    element=element,
                    status="verified",
                    confidence=0.95,
                    notes=f"Matches current Etsy UI ({category})",
                    source="known_ui_database"
                )

            # Partial match
            for item in items:
                if element_lower in item.lower() or item.lower() in element_lower:
                    return VerificationResult(
                        element=element,
                        status="verified",
                        confidence=0.8,
                        notes=f"Partial match to '{item}' in {category}",
                        source="known_ui_database"
                    )

        return None

    def _verify_with_claude(self, article_content: str, elements: list[UIElement]) -> dict:
        """Use Claude to verify UI elements against current Etsy knowledge."""
        if not self.client:
            return {}

        elements_text = "\n".join([
            f"- {e.text} ({e.element_type}, platform: {e.platform})"
            for e in elements[:20]  # Limit to 20 elements
        ])

        prompt = f"""You are an expert on Etsy's current user interface (as of 2024-2025).

Analyze these UI elements mentioned in an Etsy Help Center article and verify if they match the CURRENT Etsy interface:

**UI Elements Found in Article:**
{elements_text}

**Article Context:**
{article_content[:3000]}

For each UI element, determine:
1. Is this UI element/path CURRENTLY accurate on Etsy?
2. If outdated, what is the CURRENT correct UI path or button name?
3. Confidence level (high/medium/low)

Consider:
- Etsy Shop Manager layout and navigation
- Etsy buyer account navigation
- Etsy mobile app (iOS/Android) interface
- Recent UI changes in 2024-2025

Return a JSON object:
```json
{{
  "verifications": [
    {{
      "element": "<element text>",
      "status": "<verified|outdated|uncertain>",
      "confidence": "<high|medium|low>",
      "current_ui": "<what it actually is now, if different>",
      "notes": "<explanation>"
    }}
  ],
  "critical_issues": [
    "<any major UI mismatches that would cause user confusion>"
  ],
  "overall_ui_accuracy": <0-100>,
  "recent_changes_relevant": "<any recent Etsy UI changes that affect this article>"
}}
```"""

        try:
            response = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}]
            )

            response_text = response.content[0].text
            json_match = re.search(r'\{[\s\S]*\}', response_text)
            if json_match:
                import json
                return json.loads(json_match.group())
        except Exception:
            pass

        return {}

    def verify_article(self, html_content: str, anthropic_key: str = None) -> LiveVerificationReport:
        """
        Perform comprehensive UI verification for an article.

        Args:
            html_content: The article HTML body
            anthropic_key: Optional Anthropic API key for deep verification

        Returns:
            LiveVerificationReport with all findings
        """
        if anthropic_key and not self.client:
            self.client = Anthropic(api_key=anthropic_key)

        # Extract UI elements from article
        elements = self._extract_ui_elements(html_content)

        results = []
        critical_mismatches = []
        pages_checked = []
        manual_review_items = []

        # First pass: Check against known UI database
        for element in elements:
            result = self._verify_against_known_ui(element)
            if result:
                results.append(result)
            else:
                # Mark for deeper verification
                results.append(VerificationResult(
                    element=element,
                    status="unverified",
                    confidence=0.3,
                    notes="Not found in known UI database - needs verification",
                    source="initial_check"
                ))
                manual_review_items.append(f"{element.element_type}: '{element.text}'")

        # Second pass: Use Claude for deeper verification if available
        if self.client and elements:
            soup = BeautifulSoup(html_content, "lxml")
            text_content = soup.get_text(separator=" ", strip=True)

            claude_results = self._verify_with_claude(text_content, elements)

            if claude_results:
                # Update results with Claude's verification
                for v in claude_results.get("verifications", []):
                    element_text = v.get("element", "")
                    for i, result in enumerate(results):
                        if result.element.text.lower() in element_text.lower() or element_text.lower() in result.element.text.lower():
                            status_map = {
                                "verified": "verified",
                                "outdated": "outdated",
                                "uncertain": "unverified"
                            }
                            confidence_map = {"high": 0.9, "medium": 0.7, "low": 0.4}

                            results[i] = VerificationResult(
                                element=result.element,
                                status=status_map.get(v.get("status"), "unverified"),
                                confidence=confidence_map.get(v.get("confidence"), 0.5),
                                notes=v.get("notes"),
                                current_ui=v.get("current_ui"),
                                source="claude_verification"
                            )

                            if v.get("status") == "outdated":
                                critical_mismatches.append(
                                    f"'{element_text}' → Should be '{v.get('current_ui', 'unknown')}'"
                                )
                            break

                # Add any critical issues Claude found
                critical_mismatches.extend(claude_results.get("critical_issues", []))

        # Calculate overall confidence
        if results:
            verified_count = len([r for r in results if r.status == "verified"])
            confidence_score = verified_count / len(results) if results else 0
        else:
            confidence_score = 1.0

        # Build summary
        outdated_count = len([r for r in results if r.status == "outdated"])
        unverified_count = len([r for r in results if r.status == "unverified"])

        summary_parts = []
        if outdated_count > 0:
            summary_parts.append(f"⚠️ {outdated_count} OUTDATED UI reference(s) found")
        if unverified_count > 0:
            summary_parts.append(f"❓ {unverified_count} UI element(s) could not be verified")
        if not summary_parts:
            summary_parts.append("✅ All UI references appear current")

        verification_summary = ". ".join(summary_parts)

        return LiveVerificationReport(
            elements_found=elements,
            results=results,
            etsy_pages_checked=pages_checked,
            verification_summary=verification_summary,
            critical_mismatches=critical_mismatches,
            confidence_score=confidence_score,
            needs_manual_review=len(critical_mismatches) > 0 or unverified_count > 3,
            manual_review_items=manual_review_items[:10]  # Limit to 10
        )
