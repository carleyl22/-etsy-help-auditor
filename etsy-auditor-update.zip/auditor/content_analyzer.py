"""Content analyzer using Claude API for detailed article auditing."""

import json
import re
from dataclasses import dataclass, field
from typing import Optional
from anthropic import Anthropic
from bs4 import BeautifulSoup


@dataclass
class Issue:
    """Represents a single audit issue."""
    category: str
    severity: str
    description: str
    location: Optional[str] = None
    recommendation: Optional[str] = None
    original_text: Optional[str] = None
    suggested_text: Optional[str] = None


@dataclass
class AnalysisResult:
    """Results from content analysis."""
    overall_score: int
    audience_detected: str
    audience_mismatch: bool
    issues: list[Issue] = field(default_factory=list)
    has_web_instructions: bool = False
    has_app_instructions: bool = False
    hardcoded_links: list[str] = field(default_factory=list)
    member_services_flag: bool = False
    flag_reason: Optional[str] = None
    raw_analysis: Optional[str] = None

    # New detailed fields
    title_analysis: Optional[str] = None
    structure_analysis: Optional[str] = None
    completeness_analysis: Optional[str] = None
    readability_score: Optional[int] = None
    strengths: list[str] = field(default_factory=list)
    quick_wins: list[str] = field(default_factory=list)
    category_scores: dict = field(default_factory=dict)


AUDIT_PROMPT = """You are an expert Help Center content auditor for Etsy's support documentation. Perform an EXTREMELY DETAILED audit of this article.

## Article Information
**Title:** {title}
**URL:** {url}
**Section:** {section}
**Declared Audience (from URL):** {declared_segment}

## Full Article Content:
{content}

---

## Your Audit Task

Analyze this article with extreme thoroughness. For EVERY issue you find, you MUST:
1. Quote the EXACT problematic text
2. Explain specifically what's wrong
3. Provide the EXACT rewritten text to fix it

### Audit Categories

**1. TITLE & SEO (Score 0-100)**
- Does the title match what users would search for?
- Is it action-oriented? (e.g., "How to..." vs passive titles)
- Is it specific enough but not too long?
- Does it accurately represent the content?

**2. AUDIENCE ALIGNMENT (Score 0-100)**
- Is this clearly for Buyers, Sellers, or Both?
- Are there any terms that would confuse the wrong audience?
- Look for: "Shop Manager" (seller), "Your order" (buyer), "listing" (seller), "purchase" (buyer)
- Flag ANY seller terms in buyer articles or vice versa

**3. ACTIONABLE - Step Completeness (Score 0-100)**
- Are ALL steps included? Can a user actually complete the task?
- Is each step specific? (Bad: "Go to settings" / Good: "Select Shop Manager > Settings > Options")
- Are button/link names EXACT matches to the current UI?
- Are there BOTH web AND app instructions? If not, flag as critical.
- For each platform missing: specify exactly which steps need app/web alternatives

**4. ACTIONABLE - UI Accuracy (Score 0-100)**
- Check every navigation path mentioned
- Check every button name, menu item, tab name
- Flag anything that might be outdated
- Quote the exact UI reference and note if it seems current or potentially outdated

**5. BRIEF - Conciseness (Score 0-100)**
- Flag EVERY instance of:
  - Filler phrases ("In order to", "Please note that", "It's important to remember")
  - Marketing speak ("We're excited to", "Great news!")
  - Redundant words ("completely free", "very unique")
  - Unnecessary hedging ("You may want to consider")
  - Legal jargon that could be simplified
- For EACH instance: quote it and provide a tighter rewrite

**6. BRIEF - Scannability (Score 0-100)**
- Are paragraphs short (3-4 sentences max)?
- Are bullet points used effectively?
- Is information chunked logically?
- Are headers descriptive and helpful?

**7. TARGETED - Information Hierarchy (Score 0-100)**
- Is the most important information FIRST?
- Are critical limitations/requirements stated upfront?
- Is the "why" explained before the "how" when needed?
- Is there information that should be moved up or down?

**8. TARGETED - Scope Appropriateness (Score 0-100)**
- Is the article focused on ONE clear task/topic?
- Is anything missing that users would expect?
- Is anything included that belongs in a different article?

**9. TECHNICAL HYGIENE (Score 0-100)**
- Links with hardcoded language tags (/en-us/, /de-de/, etc.) - LIST ALL
- Internal links that might be broken
- Missing links where they'd be helpful
- Inconsistent formatting

**10. ACCESSIBILITY & INCLUSIVITY (Score 0-100)**
- Is language inclusive?
- Are instructions clear for users of all technical levels?
- Are there assumptions about user knowledge that should be explained?

---

## Response Format

Return a JSON object with this EXACT structure:

```json
{{
  "overall_score": <0-100>,
  "category_scores": {{
    "title_seo": <0-100>,
    "audience_alignment": <0-100>,
    "step_completeness": <0-100>,
    "ui_accuracy": <0-100>,
    "conciseness": <0-100>,
    "scannability": <0-100>,
    "information_hierarchy": <0-100>,
    "scope": <0-100>,
    "technical_hygiene": <0-100>,
    "accessibility": <0-100>
  }},
  "audience_detected": "<Buyer|Seller|Both>",
  "audience_mismatch": <true|false>,
  "audience_mismatch_details": "<specific examples if mismatch>",
  "has_web_instructions": <true|false>,
  "has_app_instructions": <true|false>,
  "platform_gap_details": "<what's missing for which platform>",

  "title_analysis": "<detailed analysis of the title - what works, what doesn't, suggested rewrite if needed>",
  "structure_analysis": "<analysis of how well the article is organized>",
  "completeness_analysis": "<what's missing, what extra steps are needed>",

  "strengths": [
    "<specific thing the article does well>",
    "<another strength with example>"
  ],

  "quick_wins": [
    "<easy fix that would improve the article significantly>",
    "<another quick win>"
  ],

  "issues": [
    {{
      "category": "<title_seo|audience|actionable|brief|targeted|technical|accessibility>",
      "severity": "<critical|warning|suggestion>",
      "description": "<clear description of the problem>",
      "location": "<where in the article - be specific>",
      "original_text": "<EXACT quote from article>",
      "suggested_text": "<your rewritten version>",
      "recommendation": "<additional context on why this matters>"
    }}
  ],

  "hardcoded_links": ["<list of any links with /en-us/ or similar>"],

  "member_services_flag": <true|false>,
  "flag_reason": "<if flagged, explain what needs human verification>",

  "summary": "<2-3 sentence executive summary of the audit findings>",

  "rewrite_priority": [
    {{
      "priority": 1,
      "section": "<which part to fix first>",
      "reason": "<why this is highest priority>"
    }},
    {{
      "priority": 2,
      "section": "<second priority>",
      "reason": "<why>"
    }}
  ]
}}
```

## Critical Instructions:
1. Be SPECIFIC - vague feedback is useless
2. QUOTE exact text from the article for every issue
3. PROVIDE exact rewrites, not just "make it shorter"
4. Find AT LEAST 5-10 issues if the article isn't perfect
5. A score of 90+ should be rare - most articles have room for improvement
6. Focus on issues that impact USER SUCCESS, not just style preferences
"""


class ContentAnalyzer:
    """Analyzes article content using Claude API."""

    def __init__(self, api_key: str, model: str = "claude-sonnet-4-20250514"):
        self.client = Anthropic(api_key=api_key)
        self.model = model

    def _extract_text(self, html_content: str) -> str:
        """Extract readable text from HTML content."""
        soup = BeautifulSoup(html_content, "lxml")
        for element in soup(["script", "style"]):
            element.decompose()
        text = soup.get_text(separator="\n", strip=True)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text

    def _extract_links(self, html_content: str) -> list[dict]:
        """Extract all links from HTML content."""
        soup = BeautifulSoup(html_content, "lxml")
        links = []
        for a in soup.find_all("a", href=True):
            links.append({
                "text": a.get_text(strip=True),
                "href": a["href"]
            })
        return links

    def _check_hardcoded_links(self, html_content: str) -> list[str]:
        """Find links with hardcoded language tags."""
        soup = BeautifulSoup(html_content, "lxml")
        hardcoded = []
        pattern = re.compile(r'/hc/[a-z]{2}-[a-z]{2}/')
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if "help.etsy.com" in href or href.startswith("/hc/"):
                if pattern.search(href):
                    hardcoded.append(href)
        return hardcoded

    def analyze(self, article) -> AnalysisResult:
        """Analyze an article for content quality issues."""
        text_content = self._extract_text(article.body)
        hardcoded_links = self._check_hardcoded_links(article.body)

        prompt = AUDIT_PROMPT.format(
            title=article.title,
            url=article.html_url,
            section=article.section_name or "Unknown",
            declared_segment=article.audience,
            content=text_content[:20000]
        )

        response = self.client.messages.create(
            model=self.model,
            max_tokens=8000,
            messages=[{"role": "user", "content": prompt}]
        )

        response_text = response.content[0].text

        try:
            json_match = re.search(r'\{[\s\S]*\}', response_text)
            if json_match:
                analysis = json.loads(json_match.group())
            else:
                raise ValueError("No JSON found")
        except (json.JSONDecodeError, ValueError):
            return AnalysisResult(
                overall_score=0,
                audience_detected="Unknown",
                audience_mismatch=False,
                issues=[Issue(
                    category="technical",
                    severity="critical",
                    description="Failed to parse analysis response",
                    recommendation="Please try again"
                )],
                raw_analysis=response_text
            )

        # Build issues list
        issues = []
        for issue_data in analysis.get("issues", []):
            issues.append(Issue(
                category=issue_data.get("category", "technical"),
                severity=issue_data.get("severity", "warning"),
                description=issue_data.get("description", ""),
                location=issue_data.get("location"),
                recommendation=issue_data.get("recommendation"),
                original_text=issue_data.get("original_text"),
                suggested_text=issue_data.get("suggested_text")
            ))

        # Add hardcoded link issues
        all_hardcoded = list(set(hardcoded_links + analysis.get("hardcoded_links", [])))
        if all_hardcoded:
            issues.append(Issue(
                category="technical",
                severity="warning",
                description=f"Found {len(all_hardcoded)} link(s) with hardcoded language tags",
                recommendation="Remove /en-us/ or similar language tags for dynamic localization",
                original_text=", ".join(all_hardcoded[:3])
            ))

        return AnalysisResult(
            overall_score=analysis.get("overall_score", 0),
            audience_detected=analysis.get("audience_detected", "Unknown"),
            audience_mismatch=analysis.get("audience_mismatch", False),
            issues=issues,
            has_web_instructions=analysis.get("has_web_instructions", False),
            has_app_instructions=analysis.get("has_app_instructions", False),
            hardcoded_links=all_hardcoded,
            member_services_flag=analysis.get("member_services_flag", False),
            flag_reason=analysis.get("flag_reason"),
            raw_analysis=analysis.get("summary"),
            title_analysis=analysis.get("title_analysis"),
            structure_analysis=analysis.get("structure_analysis"),
            completeness_analysis=analysis.get("completeness_analysis"),
            strengths=analysis.get("strengths", []),
            quick_wins=analysis.get("quick_wins", []),
            category_scores=analysis.get("category_scores", {})
        )
